## 2025计算机图形学pj2

#### 周煜凯 谢志康 4月21日

### 整体情况

本次实验实现光线投射算法、光线跟踪算法、阴影投射，并采用抖动采样和高斯滤波，在一定程度上缓解了锯齿问题

### 代码原理

#### Phong光照模型

在光线与场景中的物体相交后，代码会遍历所有光源，并调用光源的 `getIllumination` 方法获取光照信息（方向、强度、距离）。随后，使用材质的 `shade` 方法计算光照贡献：

```cpp
colorResult += hit.getMaterial()->shade(ray, hit, lightDirection, lightIntensity);
```

`shade` 方法通常会实现Phong光照模型的公式，包括环境光、漫反射和镜面反射三部分的计算。还处理了反射光线，通过递归调用 `traceRay` 方法实现反射效果：

```cpp
colorResult += traceRay(reflectionRay, 0.0001f, bounces - 1, reflectionHit) * hit.getMaterial()->getSpecularColor();
```

#### 光线追踪

1. 检测光线与场景中物体的交点：

   ```cpp
   if (_scene.getGroup()->intersect(ray, tMin, hit)) {
   ```

2. 遍历光源，计算直接光照：

   ```cpp
   light->getIllumination(ray.pointAtParameter(hit.getT()), lightDirection, lightIntensity, distanceToLight);
   ```

3. 处理反射光线，递归调用 `traceRay`：

   ```cpp
   colorResult += traceRay(reflectionRay, 0.0001f, bounces - 1, reflectionHit) * hit.getMaterial()->getSpecularColor();
   ```

#### 阴影投射

通过生成一条从交点指向光源的阴影光线，并检测该光线是否与其他物体相交来判断是否在阴影中：

```cpp
Ray shadowRay(ray.pointAtParameter(hit.getT()), lightDirection);
Hit shadowHit(hit.getT(), nullptr, Vector3f());
bool isInShadow = _args.shadows && _scene.getGroup()->intersect(shadowRay, 0.0001f, shadowHit);
if (isInShadow) {
    continue; // 如果在阴影中，跳过当前光源
}
```

1. **阴影光线生成**：
   - 从交点沿光源方向生成一条阴影光线 (shadowRay)。
2. **阴影检测**：
   - 调用 _scene.getGroup()->intersect 方法，检测阴影光线是否与场景中的物体相交。
   - 如果相交，则当前点位于阴影中，跳过该光源的光照计算。

#### 抖动采样

抖动采样用于抗锯齿处理，在 `Renderer::Render` 方法中实现。代码通过随机数生成器为每个像素添加随机偏移，从而实现抖动采样：

```cpp
std::random_device seed;
std::mt19937 generator(seed());
std::uniform_real_distribution<float> jitterDistribution(-1, 1);
```

每个像素的光线方向会根据抖动值进行微调，从而生成多个样本，最终取平均值以平滑图像。

1. **随机偏移**：
   - 使用随机数生成器 (`std::uniform_real_distribution`) 为每个像素生成随机偏移量 (jitterX和 jitterY)。
2. **多次采样**：
   - 对每个像素进行多次采样，生成略微偏移的光线，累积颜色、法向量和深度值。
3. **平均值**：
   - 将多次采样的结果取平均值，得到最终的像素颜色，减少锯齿现象。

#### 高斯滤波

高斯滤波的实现体现在图像后处理阶段。代码通过调整图像分辨率实现滤波效果（见 `Renderer::Render`）：

1. **滤波核**：
   - 使用 3x3 的高斯滤波核 [Matrix3f(1, 2, 1, 2, 4, 2, 1, 2, 1) * (1.0f / 16)]。
2. **卷积操作**：
   - 遍历每个像素，使用滤波核对周围像素进行加权平均，计算平滑后的颜色、法向量和深度值。
3. **分辨率调整**：
   - 如果启用了滤波，图像分辨率会在渲染时提高 3 倍，滤波后再降回原始分辨率。

---

### 实验贡献

同等贡献

### 实验结果

#### Scene1![a01d](./../starter2/out/a01d.png)

![a01n](./../starter2/out/a01n.png)

![a01](./../starter2/out/a01.png)

#### Scene2![a02](./../starter2/out/a02.png)

![a02d](./../starter2/out/a02d.png)

![a02n](./../starter2/out/a02n.png)

#### Scene3![a03](./../starter2/out/a03.png)

![a03d](./../starter2/out/a03d.png)

![a03n](./../starter2/out/a03n.png)

#### Scene4![a04d](./../starter2/out/a04d.png)

![a04n](./../starter2/out/a04n.png)

![a04](./../starter2/out/a04.png)

#### Scene5![a05n](./../starter2/out/a05n.png)

![a05](./../starter2/out/a05.png)

![a05d](./../starter2/out/a05d.png)

#### Scene6![a06d](./../starter2/out/a06d.png)

![a06n](./../starter2/out/a06n.png)

![a06](./../starter2/out/a06.png)

#### Scene7![a07](./../starter2/out/a07.png)

![a07d](./../starter2/out/a07d.png)

![a07n](./../starter2/out/a07n.png)

