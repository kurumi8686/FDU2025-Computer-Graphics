#include "Material.h"
Vector3f Material::shade(const Ray &ray,
    const Hit &hit,
    const Vector3f &dirToLight,
    const Vector3f &lightIntensity)
{
    Vector3f diffuse=std::max(0.0f,Vector3f::dot(dirToLight,hit.getNormal()))*_diffuseColor*lightIntensity;
    Vector3f dirReflect=ray.getDirection()-2*Vector3f::dot(ray.getDirection(),hit.getNormal())*hit.getNormal();
    Vector3f specular=std::pow(std::max(0.0f,Vector3f::dot(dirToLight,dirReflect)),_shininess)*_specularColor*lightIntensity;
    return diffuse+specular;
}
