#include "Renderer.h"

#include "ArgParser.h"
#include "Camera.h"
#include "Image.h"
#include "Ray.h"
#include "VecUtils.h"

#include <limits>
#include <random>


Renderer::Renderer(const ArgParser &args) :
    _args(args),
    _scene(args.input_file)
{
}

void Renderer::Render() {   
    int width = _args.width;
    int height = _args.height;

    // 如果启用了滤波，调整图像分辨率
    if (_args.filter) {
        width *= 3;
        height *= 3;
    }

    Image colorImage(width, height);
    Image normalImage(width, height);
    Image depthImage(width, height);

    // 随机数生成器，用于抗锯齿抖动
    std::random_device seed;
    std::mt19937 generator(seed());
    std::uniform_real_distribution<float> jitterDistribution(-1, 1);

    Camera* camera = _scene.getCamera();

    // 遍历每个像素
    for (int y = 0; y < height; ++y) {
        float normalizedY = 2 * (y / (height - 1.0f)) - 1.0f;

        for (int x = 0; x < width; ++x) {
            float normalizedX = 2 * (x / (width - 1.0f)) - 1.0f;

            Vector3f accumulatedColor, accumulatedNormal;
            float accumulatedDepth = 0.0f;

            // 抖动采样（抗锯齿）
            if (_args.jitter) {
                const int samples = 16;
                for (int i = 0; i < samples; ++i) {
                    float jitterX = jitterDistribution(generator) / width;
                    float jitterY = jitterDistribution(generator) / height;

                    Ray ray = camera->generateRay(Vector2f(normalizedX + jitterX, normalizedY + jitterY));
                    Hit hit;
                    accumulatedColor += traceRay(ray, camera->getTMin(), _args.bounces, hit);
                    accumulatedNormal += (hit.getNormal() + 1.0f) / 2.0f;
                    accumulatedDepth += hit.getT();
                }
                accumulatedColor /= samples;
                accumulatedNormal /= samples;
                accumulatedDepth /= samples;
            } else {
                // 无抖动采样
                Ray ray = camera->generateRay(Vector2f(normalizedX, normalizedY));
                Hit hit;
                accumulatedColor = traceRay(ray, camera->getTMin(), _args.bounces, hit);
                accumulatedNormal = (hit.getNormal() + 1.0f) / 2.0f;
                accumulatedDepth = hit.getT();
            }

            // 设置像素值
            colorImage.setPixel(x, y, accumulatedColor);
            normalImage.setPixel(x, y, accumulatedNormal);

            float depthRange = _args.depth_max - _args.depth_min;
            if (depthRange > 0) {
                float normalizedDepth = (accumulatedDepth - _args.depth_min) / depthRange;
                depthImage.setPixel(x, y, Vector3f(normalizedDepth));
            }
        }
    }

    // 如果启用了滤波，应用高斯滤波器
    if (_args.filter) {
        Image filteredColorImage(_args.width, _args.height);
        Image filteredNormalImage(_args.width, _args.height);
        Image filteredDepthImage(_args.width, _args.height);

        Matrix3f filterKernel = Matrix3f(1, 2, 1, 2, 4, 2, 1, 2, 1) * (1.0f / 16);

        for (int i = 0; i < _args.width; ++i) {
            for (int j = 0; j < _args.height; ++j) {
                Vector3f filteredColor, filteredNormal, filteredDepth;

                for (int ki = 0; ki < 3; ++ki) {
                    for (int kj = 0; kj < 3; ++kj) {
                        filteredColor += filterKernel(ki, kj) * colorImage.getPixel(3 * i + ki, 3 * j + kj);
                        filteredNormal += filterKernel(ki, kj) * normalImage.getPixel(3 * i + ki, 3 * j + kj);
                        filteredDepth += filterKernel(ki, kj) * depthImage.getPixel(3 * i + ki, 3 * j + kj);
                    }
                }

                filteredColorImage.setPixel(i, j, filteredColor);
                filteredNormalImage.setPixel(i, j, filteredNormal);
                filteredDepthImage.setPixel(i, j, filteredDepth);
            }
        }

        colorImage = filteredColorImage;
        normalImage = filteredNormalImage;
        depthImage = filteredDepthImage;
    }

    // 保存图像文件
    if (!_args.output_file.empty()) {
        colorImage.savePNG(_args.output_file);
    }
    if (!_args.depth_file.empty()) {
        depthImage.savePNG(_args.depth_file);
    }
    if (!_args.normals_file.empty()) {
        normalImage.savePNG(_args.normals_file);
    }
}


Vector3f Renderer::traceRay(const Ray &ray, float tMin, int bounces, Hit &hit) const {
    // 如果光线与场景中的物体相交
    if (_scene.getGroup()->intersect(ray, tMin, hit)) {
        Vector3f colorResult;

        // 遍历场景中的所有光源
        for (auto light : _scene.lights) {
            Vector3f lightDirection, lightIntensity;
            float distanceToLight;

            // 获取光源的照明信息
            light->getIllumination(ray.pointAtParameter(hit.getT()), lightDirection, lightIntensity, distanceToLight);

            // 检查阴影
            Ray shadowRay(ray.pointAtParameter(hit.getT()), lightDirection);
            Hit shadowHit(hit.getT(), nullptr, Vector3f());
            bool isInShadow = _args.shadows && _scene.getGroup()->intersect(shadowRay, 0.0001f, shadowHit);

            if (isInShadow) {
                continue; // 如果在阴影中，跳过当前光源
            }

            // 计算光照贡献
            colorResult += hit.getMaterial()->shade(ray, hit, lightDirection, lightIntensity);
        }

        // 处理反射光线
        if (bounces > 0) {
            Vector3f reflectionDirection = ray.getDirection() - 2 * Vector3f::dot(ray.getDirection(), hit.getNormal()) * hit.getNormal();
            Ray reflectionRay(ray.pointAtParameter(hit.getT()), reflectionDirection);
            Hit reflectionHit;

            // 递归追踪反射光线
            colorResult += traceRay(reflectionRay, 0.0001f, bounces - 1, reflectionHit) * hit.getMaterial()->getSpecularColor();
        }

        // 添加环境光的贡献
        return colorResult + _scene.getAmbientLight() * hit.getMaterial()->getDiffuseColor();
    } else {
        // 如果光线未与任何物体相交，返回背景颜色
        return _scene.getBackgroundColor(ray.getDirection());
    }
}