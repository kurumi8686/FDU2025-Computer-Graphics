#include "Object3D.h"

bool Sphere::intersect(const Ray &r, float tmin, Hit &h) const
{
    // BEGIN STARTER

    // We provide sphere intersection code for you.
    // You should model other intersection implementations after this one.

    // Locate intersection point ( 2 pts )
    const Vector3f &rayOrigin = r.getOrigin(); //Ray origin in the world coordinate
    const Vector3f &dir = r.getDirection();

    Vector3f origin = rayOrigin - _center;      //Ray origin in the sphere coordinate

    float a = dir.absSquared();
    float b = 2 * Vector3f::dot(dir, origin);
    float c = origin.absSquared() - _radius * _radius;

    // no intersection
    if (b * b - 4 * a * c < 0) {
        return false;
    }

    float d = sqrt(b * b - 4 * a * c);

    float tplus = (-b + d) / (2.0f*a);
    float tminus = (-b - d) / (2.0f*a);

    // the two intersections are at the camera back
    if ((tplus < tmin) && (tminus < tmin)) {
        return false;
    }

    float t = 10000;
    // the two intersections are at the camera front
    if (tminus > tmin) {
        t = tminus;
    }

    // one intersection at the front. one at the back 
    if ((tplus > tmin) && (tminus < tmin)) {
        t = tplus;
    }

    if (t < h.getT()) {
        Vector3f normal = r.pointAtParameter(t) - _center;
        normal = normal.normalized();
        h.set(t, this->material, normal);
        return true;
    }
    // END STARTER
    return false;
}

// Add object to group
void Group::addObject(Object3D *obj) {
    m_members.push_back(obj);
}

// Return number of objects in group
int Group::getGroupSize() const {
    return (int)m_members.size();
}

bool Group::intersect(const Ray &r, float tmin, Hit &h) const
{
    // BEGIN STARTER
    // we implemented this for you
    bool hit = false;
    for (Object3D* o : m_members) {
        if (o->intersect(r, tmin, h)) {
            hit = true;
        }
    }
    return hit;
    // END STARTER
}


Plane::Plane(const Vector3f &normal, float d, Material *m) : Object3D(m) {
    _d=d;
    _normal=normal;
}
bool Plane::intersect(const Ray &r, float tmin, Hit &h) const
{
    float direction=Vector3f::dot(r.getDirection(),_normal);
    if(fabs(direction)<1e-8)return false;

    float t=Vector3f::dot(_normal*_d-r.getOrigin(),_normal)/direction;
    if(t<=tmin||t>=h.getT())return false;
    
    h.set(t,material,_normal);
    return true;
}
bool Triangle::intersect(const Ray &r, float tmin, Hit &h) const 
{
    Vector3f originToVertex=r.getOrigin()-_v[0];
    Vector3f edge1=_v[1]-_v[0];
    Vector3f edge2=_v[2]-_v[0];
    Vector3f directionCrossEdge2=Vector3f::cross(r.getDirection(),edge2);
    Vector3f originCrossEdge1=Vector3f::cross(originToVertex,edge1);

    float S1E1=Vector3f::dot(directionCrossEdge2,edge1);
    if(fabs(S1E1)<1e-8)return false;
    float t=Vector3f::dot(originCrossEdge1,edge2)/S1E1;
    float barycentric1=Vector3f::dot(directionCrossEdge2,originToVertex)/S1E1;
    float barycentric2=Vector3f::dot(originCrossEdge1,r.getDirection())/S1E1;

    if(t>=tmin&&t<h.getT()&&barycentric1>=0.0f&&barycentric2>=0.0f&&(1-barycentric1-barycentric2)>=0.0f){
        h.set(t,material,(1-barycentric1-barycentric2)*_normals[0]+barycentric1*_normals[1]+barycentric2*_normals[2]);
        return true;
    }
    return false;
}


Transform::Transform(const Matrix4f &m,
    Object3D *obj) : _object(obj) {
    MatPoint=m;
    MatVector=MatPoint.getSubmatrix3x3(0,0).inverse().transposed();
    revMatPoint=m.inverse();
    // TODO implement Transform constructor
}
bool Transform::intersect(const Ray &r, float tmin, Hit &h) const
{
    Vector4f transformedOrigin=revMatPoint*Vector4f(r.getOrigin(),1.0f);
    Vector3f transformedDirection=revMatPoint.getSubmatrix3x3(0,0)*r.getDirection(); 
    Ray ray(transformedOrigin.xyz(),transformedDirection);

    Vector3f transformedTMinPoint=(revMatPoint*Vector4f(r.pointAtParameter(tmin),1.0f)).xyz();
    float transformedTMin=(transformedTMinPoint-ray.getOrigin()).abs();

    Hit hit;
    if(_object->intersect(ray,transformedTMin,hit)){
        Vector3f transformedNormal=(MatVector*hit.normal).normalized();
        Vector4f hitPoint=MatPoint*Vector4f(ray.pointAtParameter(hit.getT()),1.0f);
        float t=(hitPoint.xyz()-r.getOrigin()).abs();
        if(t<h.t&&t>tmin){
            h.set(t,hit.material,transformedNormal);
            return true;
        }
        return false; 
    }
    return false;
}