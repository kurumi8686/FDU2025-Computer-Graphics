#include "surf.h"
#include "vertexrecorder.h"
using namespace std;

const float c_pi = 3.14159265358979323846f;

namespace {
    // We're only implenting swept surfaces where the profile curve is
    // flat on the xy-plane.  This is a check function.
    static bool checkFlat(const Curve &profile) {
        for (unsigned i=0; i<profile.size(); i++)
            if (profile[i].V[2] != 0.0 ||
                profile[i].T[2] != 0.0 ||
                profile[i].N[2] != 0.0)
                return false;
    
        return true;
    }
}

// DEBUG HELPER
Surface quad() { 
	Surface ret;
    // 頂點坐標
	ret.VV.push_back(Vector3f(-1, -1, 0));
	ret.VV.push_back(Vector3f(+1, -1, 0));
	ret.VV.push_back(Vector3f(+1, +1, 0));
	ret.VV.push_back(Vector3f(-1, +1, 0));

    // 法向量（朝 z 軸正方向）
	ret.VN.push_back(Vector3f(0, 0, 1));
	ret.VN.push_back(Vector3f(0, 0, 1));
	ret.VN.push_back(Vector3f(0, 0, 1));
	ret.VN.push_back(Vector3f(0, 0, 1));

    // 三角形面（逆時針順序）
	ret.VF.push_back(Tup3u(0, 1, 2));
	ret.VF.push_back(Tup3u(0, 2, 3));
	return ret;
}

// 功能函數：生成三角形
static void generateTriangleFaces(Surface& surface, size_t profile_size, size_t sweep_steps, bool is_closed) {
    for (size_t step = 0; step < sweep_steps - (is_closed ? 0 : 1); ++step) {
        size_t curr_offset = step * profile_size;  // 當前輪廓的起始頂點索引
        size_t next_offset = ((step + 1) % sweep_steps) * profile_size;  // 下一個輪廓的起始頂點索引（閉合時循環）
        for (size_t j = 0; j + 1 < profile_size; ++j) {
            // 生成兩個逆時針三角形，構成一個四邊形
            surface.VF.push_back(Tup3u(curr_offset + j, curr_offset + j + 1, next_offset + j));
            surface.VF.push_back(Tup3u(next_offset + j, curr_offset + j + 1, next_offset + j + 1));
        }
    }
}

// 生成旋轉曲面
Surface makeSurfRev(const Curve &profile, unsigned num_steps) {
    Surface surface;
    // surface = quad();

    if (!checkFlat(profile)) {
        cerr << "surfRev profile curve must be flat on xy plane." << endl;
        exit(0);
    }

    // 沿 y 軸旋轉輪廓曲線生成表面
    for (size_t step = 0; step < num_steps; ++step) {
        float theta = 2 * c_pi * step / num_steps;  // 當前旋轉角度
        Matrix4f rotation = Matrix4f::rotateY(theta);  // 繞 y 軸旋轉矩陣
        Matrix4f N_transform = rotation.inverse().transposed();  // 法向量變換矩陣

        // 對每個輪廓點應用旋轉
        for (const auto& point : profile) {
            surface.VV.push_back((rotation * Vector4f(point.V, 1.0f)).xyz());  // 頂點坐標
            surface.VN.push_back((N_transform * Vector4f(-point.N, 1.0f)).xyz());  // 反向法向量
        }
    }

    // 生成三角形面，旋轉曲面是閉合的
    generateTriangleFaces(surface, profile.size(), num_steps, true);
 
    return surface;
}

// 生成廣義圓柱體
Surface makeGenCyl(const Curve &profile, const Curve &sweep) {
    Surface surface;
    // surface = quad();

    if (!checkFlat(profile)) {
        cerr << "genCyl profile curve must be flat on xy plane." << endl;
        exit(0);
    }

    // 沿掃掠曲線生成輪廓曲線的副本
    for (size_t i = 0; i < sweep.size(); ++i) {
        // 使用掃掠曲線的局部坐标系 (N, B, T, V) 構造變換矩陣
        Matrix4f transform;
        transform.setCol(0, Vector4f(sweep[i].N, 0.0f));  // x 軸對應法向量 N
        transform.setCol(1, Vector4f(sweep[i].B, 0.0f));  // y 軸對應次法向量 B
        transform.setCol(2, Vector4f(sweep[i].T, 0.0f));  // z 軸對應切向量 T
        transform.setCol(3, Vector4f(sweep[i].V, 1.0f));  // 平移到掃掠點 V
        Matrix4f N_transform = transform.inverse().transposed();  // 法向量變換矩陣

        // 對每個輪廓點應用變換
        for (const auto& point : profile) {
            surface.VV.push_back((transform * Vector4f(point.V, 1.0f)).xyz());  // 頂點坐標
            surface.VN.push_back((N_transform * Vector4f(-point.N, 1.0f)).xyz());  // 反向法向量
        }
    }

    // 生成三角形面，廣義圓柱體不閉合
    generateTriangleFaces(surface, profile.size(), sweep.size(), false);

    return surface;
}

void recordSurface(const Surface &surface, VertexRecorder* recorder) {
	const Vector3f WIRECOLOR(0.4f, 0.4f, 0.4f);
    for (int i=0; i<(int)surface.VF.size(); i++) {
		recorder->record(surface.VV[surface.VF[i][0]], surface.VN[surface.VF[i][0]], WIRECOLOR);
		recorder->record(surface.VV[surface.VF[i][1]], surface.VN[surface.VF[i][1]], WIRECOLOR);
		recorder->record(surface.VV[surface.VF[i][2]], surface.VN[surface.VF[i][2]], WIRECOLOR);
    }
}

void recordNormals(const Surface &surface, VertexRecorder* recorder, float len) {
	const Vector3f NORMALCOLOR(0, 1, 1);
    for (int i=0; i<(int)surface.VV.size(); i++) {
		recorder->record_poscolor(surface.VV[i], NORMALCOLOR);
		recorder->record_poscolor(surface.VV[i] + surface.VN[i] * len, NORMALCOLOR);
    }
}

void outputObjFile(ostream &out, const Surface &surface) {
    for (int i=0; i<(int)surface.VV.size(); i++)
        out << "v  "
            << surface.VV[i][0] << " "
            << surface.VV[i][1] << " "
            << surface.VV[i][2] << endl;

    for (int i=0; i<(int)surface.VN.size(); i++)
        out << "vn "
            << surface.VN[i][0] << " "
            << surface.VN[i][1] << " "
            << surface.VN[i][2] << endl;

    out << "vt  0 0 0" << endl;
    
    for (int i=0; i<(int)surface.VF.size(); i++) {
        out << "f  ";
        for (unsigned j=0; j<3; j++) {
            unsigned a = surface.VF[i][j]+1;
            out << a << "/" << "1" << "/" << a << " ";
        }
        out << endl;
    }
}
