#include "curve.h"
#include "vertexrecorder.h"
using namespace std;

const float c_pi = 3.14159265358979323846f;

namespace
{
// Approximately equal to.  We don't want to use == because of
// precision issues with floating point.
inline bool approx(const Vector3f& lhs, const Vector3f& rhs)
{
	const float eps = 1e-8f;
	return (lhs - rhs).absSquared() < eps;
}
}


void processClosedCurve(Curve& curve, const vector<Vector3f>& control_points) {
    Vector3f start_normal = curve.front().N;
    Vector3f end_normal = curve.back().N;
    float cos_theta = Vector3f::dot(start_normal, end_normal) / start_normal.abs() / end_normal.abs();
    cerr << "curve close, cos(theta) = " << cos_theta << endl;
    if (cos_theta <= 1) {
        float theta = acos(cos_theta);  // 計算夾角
        if (Vector3f::dot(Vector3f::cross(end_normal, start_normal), curve.front().T) < 0) {
            theta = -theta;  // 調整旋轉方向
        }
        for (size_t i = 0; i < curve.size(); ++i) {
            float angle = theta * i / curve.size();  // 線性插值角度
            curve[i].N = Vector3f(cos(angle) * curve[i].N + sin(angle) * curve[i].B);
            curve[i].B = Vector3f::cross(curve[i].T, curve[i].N).normalized();
        }
    }
}


Curve evalBezier(const vector< Vector3f >& control_points, unsigned num_steps) {
	// Check
	if (control_points.size() < 4 || control_points.size() % 3 != 1) {
		cerr << "evalBezier must be called with 3n+1 control points." << endl;
		exit(0);
	}

	// TODO:
	// You should implement this function so that it returns a Curve
	// (e.g., a vector< CurvePoint >).  The variable "steps" tells you    --> num_steps
	// the number of points to generate on each piece of the spline.
	// At least, that's how the sample solution is implemented and how
	// the SWP files are written.  But you are free to interpret this
	// variable however you want, so long as you can control the
	// "resolution" of the discretized spline curve with it.

	// Make sure that this function computes all the appropriate
	// Vector3fs for each CurvePoint: V,T,N,B.
	// [NBT] should be unit and orthogonal.

	// Also note that you may assume that all Bezier curves that you
	// receive have G1 continuity.  Otherwise, the TNB will not be
	// be defined at points where this does not hold.

	// 標準三次 Bézier 基矩陣 BEZ，用於計算位置 V 和切向量 T
	const Matrix4f BEZIER_BASIS = Matrix4f (
		1, -3,  3, -1,
		0,  3, -6,  3,
		0,  0,  3, -3,
		0,  0,  0,  1
	);

    // 計算曲線段數和總點數
    size_t num_segments = (control_points.size() - 1) / 3;  // 每段需要 4 個控制點
    Curve curve_points(num_segments * num_steps + 1);       // 預分配曲線點數

    // 生成每段曲線的點
    for (size_t segment = 0; segment < num_segments; ++segment) {
        for (size_t step = 0; step < num_steps; ++step) {
            float t = static_cast<float>(step) / num_steps;
            size_t idx = segment * num_steps + step;  // 當前曲線點的索引

            // 計算位置 V 和切向量 T 的權重
            Vector4f pos_weights = BEZIER_BASIS * Vector4f(1, t, t*t, t*t*t);
            Vector4f tan_weights = BEZIER_BASIS * Vector4f(0, 1, 2*t, 3*t*t);

            // 初始化位置和切向量
            curve_points[idx].V = Vector3f(0, 0, 0);
            curve_points[idx].T = Vector3f(0, 0, 0);

            // 根據控制點計算位置 V 和切向量 T
            for (size_t k = 0; k < 4; ++k) {
                curve_points[idx].V += pos_weights[k] * control_points[3*segment + k];
                curve_points[idx].T += tan_weights[k] * control_points[3*segment + k];
            }
            curve_points[idx].T.normalize();
        }
    }

    // 處理最後一點（t = 1.0）
    size_t last_idx = num_segments * num_steps;
    float t = 1.0f;
    Vector4f pos_weights = BEZIER_BASIS * Vector4f(1, t, t*t, t*t*t);
    Vector4f tan_weights = BEZIER_BASIS * Vector4f(0, 1, 2*t, 3*t*t);

    curve_points[last_idx].V = Vector3f(0, 0, 0);
    curve_points[last_idx].T = Vector3f(0, 0, 0);

    for (size_t k = 0; k < 4; ++k) {
        curve_points[last_idx].V += pos_weights[k] * control_points[3 * (num_segments - 1) + k];
        curve_points[last_idx].T += tan_weights[k] * control_points[3 * (num_segments - 1) + k];
    }
    curve_points[last_idx].T.normalize();

    // 計算初始法向量 N 和次法向量 B
    if (approx(curve_points[0].T, Vector3f(0, 0, 1))) curve_points[0].N = Vector3f::cross(Vector3f(1, 0, 0), curve_points[0].T).normalized();
    else curve_points[0].N = Vector3f::cross(Vector3f(0, 0, 1), curve_points[0].T).normalized();

    curve_points[0].B = Vector3f::cross(curve_points[0].T, curve_points[0].N).normalized();

    // 遞推計算後續點的 N 和 B
    for (size_t i = 1; i < num_segments * num_steps + 1; ++i) {
        curve_points[i].N = Vector3f::cross(curve_points[i - 1].B, curve_points[i].T).normalized();
        curve_points[i].B = Vector3f::cross(curve_points[i].T, curve_points[i].N).normalized();
    }

    // 處理閉合曲線：調整 N 和 B 的平滑過渡
    if (approx(control_points.front(), control_points.back()))
        processClosedCurve(curve_points, control_points);
    
	cerr << "\t>>> evalBezier has been called with the following input:" << endl;
	cerr << "\t>>> Control points (type vector< Vector3f >): " << endl;
	for (int i = 0; i < (int)control_points.size(); ++i) {
		cerr << "\t>>> " << control_points[i] << endl;
	}
	cerr << "\t>>> Steps (type steps): " << num_steps << endl;
	cerr << "\t>>> Returning curve." << endl;

	// Right now this will just return this empty curve.
	return curve_points;
}

Curve evalBspline(const vector< Vector3f >& control_points, unsigned num_steps) {
	// Check
	if (control_points.size() < 4) {
		cerr << "evalBspline must be called with 4 or more control points." << endl;
		exit(0);
	}

	// TODO:
	// It is suggested that you implement this function by changing
	// basis from B-spline to Bezier.  That way, you can just call
	// your evalBezier function.

    // 定義 Bézier 和 B 樣條基矩陣
    const Matrix4f BEZIER_BASIS = Matrix4f(
        1, -3,  3, -1,
        0,  3, -6,  3,
        0,  0,  3, -3,
        0,  0,  0,  1
    );
    const Matrix4f BSPLINE_BASIS = (1.0 / 6) * Matrix4f(
        1, -3,  3, -1,
        4,  0, -6,  3,
        1,  3,  3, -3,
        0,  0,  0,  1
    );

    // 構造 B 樣條到 Bézier 的轉換矩陣
    const Matrix4f TRANSFORM_TO_BEZIER = BSPLINE_BASIS * BEZIER_BASIS.inverse();  

    // 計算曲線段數和總點數
    size_t num_segments = control_points.size() - 3;  // 每段需要 4 個控制點
    Curve curve_points(num_segments * num_steps + 1); // 預分配曲線點數

    // 將每段 B 樣條轉換為 Bézier 並生成曲線
    for (size_t segment = 0; segment < num_segments; ++segment) {
        vector<Vector3f> bezier_points(4);  // 等價的 Bézier 控制點
        for (size_t j = 0; j < 4; ++j) {
            Vector4f weights = TRANSFORM_TO_BEZIER.getCol(j);  // 轉換矩陣的列向量
            for (size_t k = 0; k < 4; ++k) {
                bezier_points[j] += weights[k] * control_points[segment + k];
            }
        }
        // 調用 evalBezier 生成曲線段
        Curve segment_curve = evalBezier(bezier_points, num_steps);
        copy(segment_curve.begin(), segment_curve.end(), curve_points.begin() + segment * num_steps);
    }

    // 計算初始法向量 N 和次法向量 B
    if (approx(curve_points[0].T, Vector3f(0, 0, 1))) curve_points[0].N = Vector3f::cross(Vector3f(1, 0, 0), curve_points[0].T).normalized();
    else curve_points[0].N = Vector3f::cross(Vector3f(0, 0, 1), curve_points[0].T).normalized();
    
    curve_points[0].B = Vector3f::cross(curve_points[0].T, curve_points[0].N).normalized();

    // 遞推計算後續點的 N 和 B
    for (size_t i = 1; i < num_segments * num_steps + 1; ++i) {
        curve_points[i].N = Vector3f::cross(curve_points[i - 1].B, curve_points[i].T).normalized();
        curve_points[i].B = Vector3f::cross(curve_points[i].T, curve_points[i].N).normalized();
    }

    // 處理閉合曲線：調整 N 和 B 的平滑過渡
    if (approx(control_points[0], control_points[control_points.size() - 3]) &&
        approx(control_points[1], control_points[control_points.size() - 2]) &&
        approx(control_points[2], control_points[control_points.size() - 1])) 
        processClosedCurve(curve_points, control_points);

	cerr << "\t>>> evalBSpline has been called with the following input:" << endl;
	cerr << "\t>>> Control points (type vector< Vector3f >): " << endl;
	for (int i = 0; i < (int)control_points.size(); ++i) {
		cerr << "\t>>> " << control_points[i] << endl;
	}
	cerr << "\t>>> Steps (type steps): " << num_steps << endl;
	cerr << "\t>>> Returning curve." << endl;

	// Return an empty curve right now.
	return curve_points;
}

Curve evalCircle(float radius, unsigned steps) {
	// This is a sample function on how to properly initialize a Curve
	// (which is a vector< CurvePoint >).

	// Preallocate a curve with steps+1 CurvePoints
	Curve R(steps + 1);

	// Fill it in counterclockwise
	for (unsigned i = 0; i <= steps; ++i)
	{
		// step from 0 to 2pi
		float t = 2.0f * c_pi * float(i) / steps;

		// Initialize position
		// We're pivoting counterclockwise around the y-axis
		R[i].V = radius * Vector3f(cos(t), sin(t), 0);

		// Tangent vector is first derivative
		R[i].T = Vector3f(-sin(t), cos(t), 0);

		// Normal vector is second derivative
		R[i].N = Vector3f(-cos(t), -sin(t), 0);

		// Finally, binormal is facing up.
		R[i].B = Vector3f(0, 0, 1);
	}

	return R;
}

void recordCurve(const Curve& curve, VertexRecorder* recorder) {
	const Vector3f WHITE(1, 1, 1);
	for (int i = 0; i < (int)curve.size() - 1; ++i) {
		recorder->record_poscolor(curve[i].V, WHITE);
		recorder->record_poscolor(curve[i + 1].V, WHITE);
	}
}

void recordCurveFrames(const Curve& curve, VertexRecorder* recorder, float framesize) {
	Matrix4f T;
	const Vector3f RED(1, 0, 0);
	const Vector3f GREEN(0, 1, 0);
	const Vector3f BLUE(0, 0, 1);
	
	const Vector4f ORGN(0, 0, 0, 1);
	const Vector4f AXISX(framesize, 0, 0, 1);
	const Vector4f AXISY(0, framesize, 0, 1);
	const Vector4f AXISZ(0, 0, framesize, 1);

	for (int i = 0; i < (int)curve.size(); ++i) {
		T.setCol(0, Vector4f(curve[i].N, 0));
		T.setCol(1, Vector4f(curve[i].B, 0));
		T.setCol(2, Vector4f(curve[i].T, 0));
		T.setCol(3, Vector4f(curve[i].V, 1));
 
		// Transform orthogonal frames into model space
		Vector4f MORGN  = T * ORGN;
		Vector4f MAXISX = T * AXISX;
		Vector4f MAXISY = T * AXISY;
		Vector4f MAXISZ = T * AXISZ;

		// Record in model space
		recorder->record_poscolor(MORGN.xyz(), RED);
		recorder->record_poscolor(MAXISX.xyz(), RED);

		recorder->record_poscolor(MORGN.xyz(), GREEN);
		recorder->record_poscolor(MAXISY.xyz(), GREEN);

		recorder->record_poscolor(MORGN.xyz(), BLUE);
		recorder->record_poscolor(MAXISZ.xyz(), BLUE);
	}
}

